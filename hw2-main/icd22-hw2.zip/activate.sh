docker run --rm -it -w /root -v "${PWD}":/root/hw2 plaslab/compiler-f20-hw2:latest /bin/bash
