dosh run plaslab/compiler-f20-hw2:latest /bin/bash
