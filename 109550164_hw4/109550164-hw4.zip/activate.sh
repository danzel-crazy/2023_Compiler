docker run --rm -it -w /root -v "${PWD}":/root/hw4 plaslab/compiler-f20-hw4:latest /bin/bash
