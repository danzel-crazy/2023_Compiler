dosh run plaslab/compiler-f20-hw4:latest /bin/bash
